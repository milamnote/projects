# Styleguide options

### Head

    <meta name='viewport' content='width=device-width, initial-scale=1' />
    <script src='https://cdn.rawgit.com/styledown/styledown/v1.0.2/data/styledown.js'></script>
    <script src='../../../style_guides/styledown.js'></script>
    <script src='../../../style_guides/bootstrap.js'></script>
    <script src='../../../style_guides/jquery.js'></script>
    <link rel='stylesheet' href='https://cdn.rawgit.com/styledown/styledown/v1.0.2/data/styledown.css' />
    <link rel='stylesheet' href='style.css' />
    <link rel='stylesheet' href='../../../style_guides/styledown.css' />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>


### Body

    <div class='sg-container' sg-content></div>
    <div style="position:absolute; left:5px; top:5px;">
    <a href="#h1">見出しレイアウト</a>
    <a href="#button">ボタンレイアウト</a>
  <div class="container">
  <div class="btn-group">
  <button type="button" class="btn btn-danger">Action</button>
  <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="caret"></span>
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <ul class="dropdown-menu">
    <li><a href="#h1">見出しレイアウト</a></li>
    <li><a href="#">Another action</a></li>
    <li><a href="#">Something else here</a></li>
    <li role="separator" class="divider"></li>
    <li><a href="#">Separated link</a></li>
  </ul>
    </div>
        </div>
    </div>