var webpack            = require("webpack-stream").webpack;
var BowerWebpackPlugin = require("bower-webpack-plugin");
var path               = require ("path");


module.exports = {

//# entryポイントを指定、複数指定できます
 entry: './deploy/js/webpack/main.jsx',

//  # 出力先の設定
    output: {
        path:__dirname + '/deploy/js/webpack/',
        filename: '[name].js'
    },


// # 他にもhtmlやcssを読み込む必要がある場合はここへ追記
    module: {
         loaders: [

           {
            test: /\.css$/,
            loader: 'style!css'
          },
      //# module.loadersで、jsx-loaderを読み込む。
         {
             test: /\.jsx$/,
             loader: 'jsx-loader?harmony'
         },

//          {
//        test: /\.jsx$/,
//        exclude: /node_modules|bower_components/,
//        loader: 'babel?stage=0'
//        },


    //  # .coffeeをcoffee-loaderに渡すように
         {test: /\.coffee$/, loader: "coffee-loader"}
    ]
     },
     //externals: {
     //    'react': 'React'//html側でreact.jsを読み込んでいる場合は必要
     //},

  //  # ファイル名の解決を設定
    resolve: {
        root: [path.join(__dirname, "libs")],
        moduleDirectories: ["libs"],
        extensions: ['', '.js', '.coffee', '.jsx']
    },

  //  # webpack用の各プラグイン
    plugins: [
//    # bower.jsonにあるパッケージをrequire出来るように
    new BowerWebpackPlugin()

//    # ↓下記では`main`で指定されたファイルが配列の場合読み込めない！
//    # new webpack.ResolverPlugin(
//    #   new webpack.ResolverPlugin.DirectoryDescriptionFilePlugin ".bower.json", ["main"]
//    # )
  ]
};

