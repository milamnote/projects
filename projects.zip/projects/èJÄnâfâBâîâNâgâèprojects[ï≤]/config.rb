#セットディレクトリーパス
http_path = "/"
#css_dir = "_release/css"
css_dir = "deploy/css"
sass_dir = "deploy/scss"
images_dir = "_release/images"
javascripts_dir = "_release/js"

# アウトプットスタイルの選択（利用するスタイルのコメントを外して利用する）（デフォルト：expanded）
 output_style = :expanded   #通常のアウトプットスタイル
# output_style = :nested     #Sassなどのネストを継承したスタイル
# output_style = :compact    #1つのCSSCSSレイクタの設定が１行になるスタイル
# output_style = :compressed #コメントを取り除いて完全に圧縮するスタイル

#フレームワークを呼びこむことが出来るパス
 additional_import_paths = ["../../framework"]

# Compassで拡張された関数で使うURLを、絶対パスか相対パスかを指定（デフォルト：false[絶対パス]）
#relative_assets = true

# デバッグ用のコメントを出力するか（デフォルト：true[出力する]）
line_comments = false


# SCSS記法とSass記法の切り替え
# Sass記法を利用する場合は、以下のコメントを外してください
# preferred_syntax = :sass

# sass-convert -R --from scss --to sass sass scss && rm -rf sass && mv scss sass
 cache = false

#ブラウザでSassを検証する設定   ←なんだか思ったようにならない
#sass_options = { :debug_info => true }
# sourcemap = true
# sourcemap = (environment == :production) ? false : true

# Compass1.0 more

# 日本語が通るように設定。
Encoding.default_external = 'utf-8'


