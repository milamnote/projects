var React = require('react');
var ihover = require('ihover');

var CommentBox = React.createClass({
  render: function() {
    return (
     <div className="commentBox">
     <link href="styles/ihover.css" rel="stylesheet">
    <!-- normal -->
    <div class="ih-item circle effect2 right_to_left"><a href="#">
        <div class="img"><img src="images/assets/6.jpg" alt="img"></div>
        <div class="info">
          <h3>Heading here</h3>
          <p>Description goes here</p>
        </div></a></div>
    <!-- end normal -->

        わけワカメ
      </div>
   );
  }
});

React.render(
  <CommentBox />,
  document.getElementById('content')
);