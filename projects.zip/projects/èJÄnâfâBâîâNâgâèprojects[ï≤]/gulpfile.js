//******** ディレクトリ設定一覧**********************************************************
//  各ディレクトリーの設定を行います。
//  使う際には、Path + ディレクトリ名か、下記の使用例のように使用して下さい。
//  今はあえて使っていないので、コメントアウトしています。
//***********************************************************************************
//
//# ディレクトリ設定 今使っていないのでコメントアウト
//var path = {
//  'imgPath': 'img', // 例）'htdocs/images'
//  'sassPath': 'deploy/scss', // 例）'htdocs/scss'
//  'cssPath': '_release/css', // 例）'htdocs/stylesheets'
//  'jsPath': '_release/js', // 例）'htdocs/javascripts'
//  'ejspath':'deploy/ejs'
//}
//
//
//#使用例 Compassのタスク
//
// pipe(行いたい処理)でsrcで取得したファイルに処理を施します :監視用ツール
//    .pipe(plumber())
//    .pipe(compass({
//      config_file: 'config.rb',
//      comments : false,
//      sass: path.sassPath,
//      css: path.cssPath,
//      image: path.imgPath,
//      ejs: path.ejspath
//    }))
//    .pipe(autoprefixer('last 2 version', 'ie 8', 'ie 7'))
//    .pipe(gulp.dest(path.cssPath + '/'))
//});
//
//



//******** 使用パッケージの呼び出し一覧*****************************************************
//  ここではnpmでDLした、gulp用のパッケージを呼び出しています。
//  DLしても、ここで呼び出さなければ利用できません。
//  また、ここでvarの次に書いた名称が、pipaで呼び出す名称になります。
//***********************************************************************************
//
//# 使用パッケージ
var gulp = require('gulp'); //OK

//# JSONファイルの読み込みに使用←EJSのサイト定義、header/footerの項目読み込み用に。
var fs = require('fs');

//# ファイルの結合
var concat = require('gulp-concat'); //OK
//# ファイルの名前変更処理
var rename = require('gulp-rename'); //OK
//# 変更されたファイルだけを処理させる
var cache = require('gulp-cached');
//# ファイルのヘッダーに注略をつける。ヘッダーテキスト：主にワードプレス用を記載しよう！
var header = require('gulp-header');  //OK
//# ファイルのフッターに注略をつける。 フッターテキストを作成しましょう
var footer = require('gulp-footer');  //OK
//# Compassのタスク（Sass/Scss）
var compass = require('gulp-compass'); //OK
//# ソースマップをつける。
var sourcemaps = require('gulp-sourcemaps'); //OK
//# CSSの圧縮
var cssmin = require('gulp-cssmin'); //OK
//# ベンダープレフィックス →Compassで自動でなるからいらない？ いや、めっちゃいる！
var autoprefixer = require("gulp-autoprefixer");  //OK
//# CSSプロパティの並び替え
var csscomb = require('gulp-csscomb'); //OK
//# 使ってないCSSを削除する
var uncss = require('gulp-uncss'); //OK
//# 散らばったメディアクエリ（＠media)をCSS内でまとめる。
//var media = require('gulp-combine-media-queries');
//# スタイルガイドジェネレーター
var styledown = require('gulp-styledown'); //OK
//# 画像圧縮
var imagemin = require('gulp-imagemin'); //OK
//# 画像圧縮 Gifをより圧縮可能に！（imageminないで利用する）
var Gifsicle = require('imagemin-gifsicle'); //OK
//# 画像圧縮 JPGをより圧縮可能に！（imageminないで利用する）
var Mozjpeg = require('imagemin-mozjpeg'); //OK
//#画像圧縮 pngをより圧縮可能に！（imageminないで利用する）
var pngquant  = require('imagemin-pngquant'); //OK
//# 画像圧縮 svgをより圧縮可能に！（imageminないで利用する）
var svgo = require('svgo');  //OK
//# モバイルアプリ画像圧縮 jpg/png画像をwebp画像へ変換！ ←何かインストール出来ない？ので、コメントアウトします。タスク済み。
//var webp = require('imagemin-webp');
//# HTML組み合わせツール
var ejs = require("gulp-ejs");   //OK
//# HTMLのインデントを綺麗に揃える
var prettify = require('gulp-prettify');
//# HTML文法チェック
var htmlhint = require("gulp-htmlhint");
//# HTMLバリデーターチェック(htmlintが使えない時はこっちで W3Cフォルダ自動作成＿結果保存)
var htmlv =require("gulp-html-validator");
//# HTML5文法チェック タスクは使えますが、使ってないのでコメントアウト。
//var html5Lint = require('gulp-html5-lint');

//# サイトマップXMLを作成する
var sitemap = require('gulp-sitemap'); //OK
//# JS圧縮ツール
var uglify = require("gulp-uglify");

//# ローカルWebサーバー
var browserSync = require("browser-sync"); //OK
//# PHP用サーバー設定用
var PHPconnect = require('gulp-connect-php');
//# コンパイルエラーが出てもwatchを止めない
var plumber = require('gulp-plumber'); //OK
//# デスクトップに通知が表示
var notify = require ('gulp-notify'); //OK
//# 制作中のWebページのスナップショットを撮
var webshot = require('gulp-webshot'); //OK
//# 制作完了ディレクトリをzip化する
var zip = require('gulp-zip'); //OK
//# CSS・JSなどをより圧縮gzip化する。
var gzip = require('gulp-gzip');
//# いらないファイル・ディレクトリを削除する
var del = require('del'); //OK
//# markdownで書いて、PDF化する
var markdownpdf = require('gulp-markdown-pdf');//オプション：https://github.com/alanshaw/markdown-pdf#options
//# markdownで書いて、html化する：PDF用のCSS落としにDL。各デザインが入っています。
var mds = require('markdown-styles'); //タスク書いていません：詳細http://mixu.net/markdown-styles/
    path = require('path');
//# markdownで、マニュアル化 HTML出力
var markdownDocs = require('gulp-markdown-docs');
//# HTMLでコメントで囲んだリンク部分をconcat＆minして、リンクを自動に書き換えてくれる
//var useref = require('gulp-useref'); //タスクを未だ書いていないのでコメントアウト
//
var exec = require('gulp-exec');





//******** 監視チェック処理まとめ**********************************************************
//
//  Watch設定をして、変更があった際に自動的にライブリロードが起こるように設定しています。（deploy/release)
//  基本コマンド gulpのみで、サーバー起動＆ブラウザ立ち上げ（各ブラウザで同時確認可能）
//  SCSS/ejs/jg/imageに変化（保存すると）があると、自動的にブラウザページを更新します。
//  スタイルガイドも同時に作成（SCSSに特定書式の書き方で、書いていくと自動的に作成されます）
//  ※HTML文法が間違っているとエラー音＆項目をコマンドプロントに内容が出ます。
//
//************************************************************************************


//# 監視チェック！変更があれば自動で動きます。（エラーが起こると止まる。）
//  コマンドプロントで、gulpと打つだけでOK! 個別に確認を撮りたい場合は、gulp タスク名（frontnoteなど)で動きます。
gulp.task("default",['server'], function() {
    gulp.watch(["deploy/js/**/*.js","!deploy/js/**/*.min.js"],["js"]);
    gulp.watch("deploy/scss/**/*.scss",["compass"]);
    gulp.watch("deploy/scss/**/*.scss",["guide"]);
//    gulp.watch("deploy/ejs/**/*.ejs",'./index.json',["ejs"]);
    gulp.watch("deploy/ejs/**/*.ejs",["ejs"]);
    gulp.watch("deploy/release/**/*.html",["hlint"]); //文法チェック。煩かったらコメントアウト。
    gulp.watch("deploy/images/*.+(jpg|jpeg|png|gif|svg)",["imagemin"]);
});


//************************************************************************************
//  サイトが完成したら、buildしちゃってくださいっ
//  gulp buildとコマンドに打つと、sitemapXML作成、Favicon作成、css.gz用htaccess作成
//  スクリーンショット(wordpress.FB用）作成します。
//
//  ごめんなさい、buildが動かないので（ぇ）１つずつコマンド打って下さい。
//  shotは、wpとfbの２つを別に打って下さい(shotは打たずに)
//
//************************************************************************************

//gulp.task('build', ['sitemap'],['favicon'],['hta'],['shot']);


//************************************************************************************
//  WordPress用設定（テスト中）：並列処理のため、今うまくうごきません。１つずつコマンド打ってください。
//  gulp wordpressとコマンドで打つと、CSSに専用header（header.txt読み込み）付与し、
//  サイト全体をコピーし、releaseフォルダへ。それらをzip化した後にクリーンします。
//************************************************************************************

//  # サイトの最後の処理だよー 最後にgulp cleanで、フォルダを綺麗にしよう！
//  ['footer']←使ってないので下げました。※タスクは有り。
//gulp.task('wordpress', ['header'],['copy'],['zip'],['clean']);



//******** ローカルライブリロード処理まとめ**********************************************************
//
//  各ライブリロードしたいタスクには、.pipe(browserSync.reload({stream:true}));を最後に記載。
//  最後のWacthで、ファイルに変更があった際に、自動的にブラウザ更新が行われるように設定しています。
//
//************************************************************************************


var php_path = "projects/r/deploy/";
//# ローカルWebサーバー
gulp.task("server", function() {
    browserSync({
        server: {
            baseDir: "deploy/release/",// ルートとなるディレクトリを指定
        },
        ghostMode: {
      location: true
    }
    });
    //# 動的ページを動かしたい場合はポートを合わせ、この内容に置き換える。
 //     browserSync.init({
//        open:true,
//        port:8080,
//        proxy:"milamdesgin-pc" + configure.php_server.port,
//        proxy:"milamdesgin-pc",
//        notify:false,

//        port:8080,
//        proxy: "milamdesgin-pc:8080/wordpress6/" + php_path,
//        files: ["*.css", "*.php", "*.cgi", "*.pl"],
//        startPath: php_path + "index.php",
//    });
    // srcフォルダ以下のファイルを監視
    gulp.watch("./deploy/**", function() {
        browserSync.reload();   // ファイルに変更があれば同期しているブラウザをリロード
});

});

//# 動的ページを動かしたい場合はポートを合わせ、この内容に置き換える。:動的サーバーのパーミッション設定をして下さいｗ
var php_path = "projects/r/deploy/";
var reload2  = browserSync.reload;
gulp.task('php', function() {
    PHPconnect.server({ base: 'build', port: 8010, keepalive: true});
});
gulp.task('browser-sync',['php'], function() {
    browserSync({
        proxy: 'milamdesgin-pc:8080/wordpress6/'+php_path,
        port: 8080,
        open: true,
        notify: false
    });
});
gulp.task('pserver', ['browser-sync'], function () {
    gulp.watch([php_path + '/*.php'], [reload2]);
});






//******** 次世代CSS！POSTCSS処理まとめ**********************************************************
//
//  次の技術に触れておくために、別項目で作成しています。テスト段階。
//  参考URL
//  http://morishitter.hatenablog.com/entry/2015/08/03/164424
//  https://html5experts.jp/t32k/17235/
//  https://github.com/postcss/postcss
//
//  SASSも使えるプラグインがあるらしい：https://www.npmjs.com/package/postscss（今は入れていません）
//
//  CSSテスト完了！使えます！ PostCSSは、自分で好きなように色々出来るらしいので勉強していきましょう！
//
//*******************************************************************************************

//# 次世代CSS:PostCSS
var cssnano = require('gulp-postcss');
//# 次世代CSS:PostCSSの現在策定段階でブラウザが未実装のCSSの記法を、今のブラウザが解釈できるようにする。
var cssnext = require('cssnext');
//# 次世代CSS:PostCSSのミックスインを使用する
var postcssmixins = require('postcss-mixins');
//# 次世代CSS:PostCSSで入れ子でCSSを記述できるようになる
var postcssnested = require('postcss-nested');
//# 次世代CSS:PostCSSでCSSで変数がつかえるようになる
var postcsssimplevars = require('postcss-simple-vars');
//# 次世代CSS:PostCSSのCSSをスペースや改行などを除いて縮小してくれる
var cssnano = require('cssnano');
//# 次世代CSS:PostCSS用のベンダープレフィックス
var autoprefixer2 = require('autoprefixer');
//# 文法チェックをします。 postcss-reporterをタスク内で、この下に書くといいみたいなんだけど・・違う方式（plumber）でやってみる！
var postcsslinter = require('postcss-bem-linter');


//# 次世代CSS:PostCSSタスク
gulp.task('postcss', function () {
    var postcss = require('gulp-postcss');
    return gulp.src('deploy/postcss/*.pcss')
    //# 監視用ツール エラーがあったら、タスクバーで窓表示します。 notifyでエラーが出た場合、デスクトップに別窓が開く設定が入っています。
    .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
        .pipe( postcss([
            // 直接postcssにrequireでプラグインを呼び出し可能。
            require('postcss-bem-linter'),
            require('postcss-mixins'),
            require('postcss-nested'),
            require('autoprefixer')({
              browsers: ['last 2 versions']
            }),
            require('postcss-simple-vars'),
            require('cssnext'),
            require('cssnano'),
        ]) )
        .pipe( gulp.dest('deploy/postcss/dest/') );
});










//******** プロジェクト詳細まとめ**********************************************************
//
//  markdown式で、プロジェクト詳細を記載。mdで保存。→PDF化して、仕様を見やすいようにしておこう。
//  projects.md()
//      サイト種類： サンプル： 期間： 費用： イメージ：
//      使用UI： 使用UX: USEフレームワーク：例：bootstrap3
//      サイト構成： サイト目的： ユーザー価値： 使用デバイス対応：可（スマフォ・タブレット・PC）
//      同業種サイト一覧：（URLと特徴まとめ）
//      クライアントの望み
//
//************************************************************************************


//# markdownで、プロジェクト詳細を記載 pdf化
gulp.task('pdf', function () {
  return gulp.src('./deploy/projects.md')
    .pipe(markdownpdf({
        cssPath:"deploy/md_css/style.css"
    }))
    .pipe(gulp.dest('deploy/'));
});





//# markdownで、マニュアル化 HTML出力
var markdownDocs = require('gulp-markdown-docs');
var __dirname = "node_modules/gulp-markdown-docs";
var __dirname2 = "node_modules/markdown-styles/layouts";
var __dirname3 = "manual/md_css";
//github-markdown.css
gulp.task('manual', function () {
  return gulp.src('manual/**.md')
    .pipe(markdownDocs('index.html', {
//    layoutStylesheetUrl: __dirname + '/resources/layout.css',
//    layoutStylesheetUrl: __dirname2 + '/github/assets/css/github-markdown.css',
        layoutStylesheetUrl: __dirname3 + '/roryg-ghostwriter/style.css',//◎
//    templatePath: __dirname2 + '/github/page.html',
//    highlightTheme: 'solarized_dark'
  }))
    .pipe(gulp.dest('./manual/'));
});


//# うごいたー♪ CSSも適応しただー（嬉）
var pandoc = require('gulp-pandoc');

gulp.task('docs', function() {
  gulp.src('manual/**/*.md')
    .pipe(pandoc({
      from: 'markdown',
      to: 'html5',
      ext: '.html',
//      args: ['--smart']
//      args: ['--css=style.css']
        args: ['--css=j:/projects/R/manual/md_css/roryg-ghostwriter/style.css']
    }))
    .pipe(gulp.dest('manual/change/'));
});


//#動くけれど、どこに出力しているのかわからない・・ というかファイルパス通ってない（ぇ 動いたら、一気にいろいろな形式で出来るんだけどな～
//var filepath="manual/*.md";
gulp.task('pandoc', function() {
  var options = {
    silent: true,
  };
  gulp.src('manual/**/*.md')
//    .pipe(exec('pandoc <%= file.path %> -f markdown -o output.docx', options))
    .pipe(exec('pandoc <%= file.epath %> -f markdown -o output.docx', options))
    .pipe(exec('pandoc <%= file.path %> -f markdown  -o output.pdf -v documentclass=ltjarticle -v classoption=a4j -v classoption=landscape --latex-engine=lualatex --toc', options))
    .pipe(exec('pandoc <%= file.path %> -f markdown  -o output.html', options))
   .pipe(exec('pandoc <%= file.path %> -f markdown -t hatena.lua -o output.text', options));
//     .pipe(gulp.dest('manua/test'));
});

gulp.task('watch', function() {
    gulp.watch('./input.md', function(event) {
        gulp.run('pandoc');
    });
});





//******** CSSファイル処理まとめ**********************************************************
//
//  通常の_release/cssに出力されるファイルに対しての処理を、一括して書いています。
//  Sass処理としてCompass、次にベンダープレフィックスでie8.7への対処。
//  基本、Sassで一枚のCSSとして出力されるように処理。いらないCSSは含めない。
//
//  【CSSファイルのみの時（コンパイルしない）】
//  その後、各ファイルを結合した後で、使っていないCSSは削除し、CSSプロパティを並び替え。
//  ベンダープレフィックスをし、最後にCSSの圧縮を行い、ファイル出力を行います。
//
//************************************************************************************


//# Sass処理Compassタスクの設定（ベンダープレフィックスを正しくしたいので、上記の書き方に変更しています。
// gulp.task(‘タスク名’,function() {});でタスクの登録をおこないます。
gulp.task('compass',function(){
// gulp.src(’ファイル’のパス)で読み出したいファイルを指定します。
 gulp.src(['deploy/scss/**/*.scss'])

// pipe(行いたい処理)でsrcで取得したファイルに処理を施します
//# ソースマップをつける
.pipe(sourcemaps.init())

//# 監視用ツール エラーがあったら、タスクバーで窓表示します。 notifyでエラーが出た場合、デスクトップに別窓が開く設定が入っています。
.pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))

//# Sass処理compass(SassをCSSヘコンパイル（変換）します)
 .pipe(compass({
 config_file : 'config.rb',
 comments : false,// こういったコメントを消す（false）
 sourcemap: true, // ソースマップファイルを出力を指定します
// debug : true,
 css : 'deploy/release/css',
 sass: 'deploy/scss',
 ejs: 'deploy/ejs/',
 image:'deploy/images'
 }))


//# ベンダープレフィックス導入：IE9,8への対応
    .pipe(autoprefixer('last 2 version', 'ie 9', 'ie 8'))

//# Souceマップを出力するパスを指定します。
 .pipe(sourcemaps.write('maps', {
      includeContent: false,
      sourceRoot: 'deploy/scss'
     }))

//# CSSの圧縮
    .pipe(cssmin())

//# 名前を変える
    .pipe(rename({
        suffix: '.min'
        }))
    .pipe(gulp.dest("deploy/release/css"))

        //# GZIP圧縮化する（スマフォ対策：.htaccessを必ず設置すること、リンク先はGzipとファイル名が同じなら、●●、cssでOK）
        .pipe(gzip())
        //# 名前を変える
        .pipe(rename({
        basename: "style",
//        prefix: "bonjour-",
        suffix: "",
        }))
        .pipe(gulp.dest("deploy/release/css"))

//# スタイルガイドジェネレーター :gzをスタイルガイドしちゃって読めませんｗ
//.pipe(styledown({
//  config: 'styledown_config.md',
//  filename: 'style_guide.html'
//}))
//# 出力先指定（cssプレフィックス、min,スタイルガイド
//      .pipe(gulp.dest('deploy/release/css'))

//# ライブリロードブラウザ設定
    .pipe(browserSync.reload({stream:true}));
});




//#ベンダープレフィックスを付ける
gulp.task('prefix', function () {
    return gulp.src('deploy/release/css/**/*.css')
//# ソースマップをつける
    .pipe(sourcemaps.init({loadMaps: true}))

        .pipe(autoprefixer({
            browsers: ['last 2 version', 'ie 9', 'ie 8'],
            cascade: false
        }))

        //# Souceマップを出力するパスを指定します。
        .pipe(sourcemaps.write('maps', {
         includeContent: false,
         sourceRoot: 'deploy/scss'
         }))

        .pipe(gulp.dest('deploy/release/css'));
});



//# CSSの圧縮
gulp.task('cssmin', function () {
    console.log('--------- cssmin task ----------');
  gulp.src("deploy/release/css/*.css")
//# 監視用ツール エラーがあったら、タスクバーで窓表示します。
 .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
        .pipe(cssmin())
        //# 名前を変える
        .pipe(rename({
            suffix: '.min'
        }))
          .pipe(gulp.dest('deploy/release/css'))
        //# GZIP圧縮化する（スマフォ対策：.htaccessを必ず設置すること）
        .pipe(gzip())
        .pipe(gulp.dest('deploy/release/css'));
});



//# スタイルガイドジェネレーター
gulp.task("guide", function() {
gulp.src('deploy/scss/**/*.scss')
.pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
.pipe(styledown({
  config: 'styledown_config.md',
  filename: 'style_guides.html'
}))
.pipe(gulp.dest('deploy/release/css/'));
});




//******** CSSファイル処理 今は基本使わない（SCSSでいらないものは含まないので）*************************

//# CSSファイルを全て結合し、style.cssファイルとして出力
gulp.task('concat', function() {
//  gulp.src("deploy/release/css/**/*.css")
      gulp.src("deploy/md_css/*.css")
  //# 監視用ツール エラーがあったら、タスクバーで窓表示します。
.pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
    .pipe(concat('style.css'))
//    .pipe(gulp.dest('deploy/release/css_concat/'));
      .pipe(gulp.dest('deploy/md_css'));
});


//# 使っていないCSSを削除
gulp.task('uncss', function() {
  gulp.src("deploy/release/css_concat/*.css")
  //# 監視用ツール エラーがあったら、タスクバーで窓表示します。
.pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
    .pipe(uncss({
      html: ["_release/**/*.html", "deploy/**/*.html"],
//   # 削除から除外するセレクタを正規表現で指定できる Javascriptに当てたものを除外しよう
//     ignore: ['.reset','',/^\.*__*/, /^\.is\-/, /^\.bx*/]
    }))
    .pipe(gulp.dest('deploy/release/css_uncss/'));
});



//# CSSプロパティの並び替え
gulp.task('csscomb', function() {
  gulp.src("deploy/release/css_uncss/*.css")
  //# 監視用ツール エラーがあったら、タスクバーで窓表示します。
 .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
 .pipe(csscomb())
 .pipe(gulp.dest('deploy/release/comb_css/'));
});

//******** CSSファイル処理 ここまで**********************************************************






//******** 画像圧縮まとめ**********************************************************
//
//  主にimagemineで、各種画像（Gif/PNG/JPG/SVO）を圧縮しています。
//  Gifだけ圧縮率が悪いので、気をつけて下さい。
//  画像圧縮は、主にスマートフォンなどから見る方に向けての配慮です。画像が重いと表示が遅くなり、即離脱に。
//  imageminで、表示が遅い場合は、WebP画像へJpg/PNG画像を変換して利用して下さい。（主にアプリ向けが望ましい）
//
//************************************************************************************

// 画像圧縮
gulp.task('imagemin', function(){
  gulp.src("deploy/images/**/*.+(jpg|jpeg|png|gif|svg)")
//# 監視用ツール エラーがあったら、タスクバーで窓表示します。
      .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
    .pipe(imagemin({
      optimizationLevel: 7,   // 試行回数
      progressive: true,      // jpgの軽量化
      interlaced:true,        // Gifの軽量化
      svgoPlugins: [{         // svgの軽量化
        removeRasterImages: true,
        cleanupListOfValues: true,
        sortAttrs: true
      }],
         use: [
         pngquant({     // pngの軽量化
          quality: 60-80,
          speed: 1
         }),
         Mozjpeg({
         progressive: true,      // jpgのロスレス圧縮 軽量化
         quality: 87
      }),
         Gifsicle({
            interlaced: true      // Gifの軽量化
        })
         ]
    }))
    .pipe(gulp.dest('deploy/release/images'))
    .pipe(browserSync.reload({stream:true}));
});


//# モバイルアプリ用にPNG/JPG画像をwebP画像に変換！ インストールができていないのでコメントアウトします。
//gulp.task('webp', function () {
//     gulp.src("deploy/images/*")
//    //# 監視用ツール エラーがあったら、タスクバーで窓表示します。
//      .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
//        .pipe(webp({
//            quality: 65,
//            sharpest:1 //オプションの詳しい内容は、https://www.npmjs.com/package/imagemin-webpを参照
//        }))
//        .pipe(gulp.dest('deploy/release/images/webp'));
//});




//******** 次世代JS：ES6に向けて処理まとめ********************************************************
//
//  一応使えるんだけど、自分がES6を熟知してないという事実(； ･`д･´)
//  コーヒースクリプトさんも入れたんだけど、設定してないという事実っ(； ･`д･´)
//  WEBPACKもつかえるよーｗ
//
//*****************************************************************************************

//# JS-babel利用
var babel = require("gulp-babel");

//#ES6文法チェックツールをいれる
var eslint = require('gulp-eslint');

gulp.task("babel", function () {
//#ES６ファイルを、JSに変換指定します。
  return  gulp.src('./deploy/js/**/*.es6')
//  return gulp.src("src/**/*.js")
    .pipe(concat("all.js"))
//# ソースマップを記載します。
    .pipe(sourcemaps.init())
    .pipe(babel())
//# ソースマップを出力します。
    .pipe(sourcemaps.write('maps', {
          includeContent: false,
          sourceRoot: 'deploy/js/es6'
         }))
    .pipe(gulp.dest("deploy/release/js/es6/change"));
});


//# WEBPACKの設定
var webpack = require('webpack-stream');
var webpackConfig = require('./webpack.config.js');
gulp.task('webpack', function() {
  return gulp.src('deploy/js/webpack/')
    .pipe(webpack(webpackConfig))
    .pipe(gulp.dest('deploy/release/js/webpack/'));
});



//******** Javascriptファイル処理まとめ**********************************************************
//
//  HTMLで読み込んでテスト済みのJSをファイル１枚に
//  なるんだけど、今のところ意味がなし。
//  ※ソースマップでは何か言われます（ぇ うん、だって、jsそのまんまだからソースマップがいらないのｗ
//
//  ⇒WEBPACKに全て移行中です。（テスト中です）
//
//*****************************************************************************************


//# JS圧縮ツール
gulp.task("js", function() {
    gulp.src(["deploy/js/**/*.js","!deploy/js/**/*.min.js"])
    //# ソースマップをつける
.pipe(sourcemaps.init())
//# 監視用ツール エラーがあったら、タスクバーで窓表示します。
      .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
     //# ファイルを一枚にする
         .pipe(concat('style.js'))
         .pipe(gulp.dest("deploy/release/js"))

    //# Souceマップを出力するパスを指定します。
          .pipe(sourcemaps.write('maps', {
          includeContent: false,
          sourceRoot: 'deploy/js'
         }))
                   .pipe(gulp.dest("deploy/release/js"))

    //# JSを圧縮する
        .pipe(uglify())
     //# 名前を変える
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest("deploy/release/js"))

        //# GZIP圧縮化する（スマフォ対策：.htaccessを必ず設置すること）
        .pipe(gzip())
        .pipe(gulp.dest("deploy/release/js"))
        .pipe(browserSync.reload({stream:true}));
});





//******** HTML&各ファイル処理まとめ**********************************************************
//
//  EJS（HTMLテンプレート）ファイルから、HTMLファイルを作成します。次にサイトマップXMLを作成。
//  CSSやJSなどに、ヘッダー（もしくはフッター）をつけて、ワードプレスにも対応可能に。
//  表示を確認したディレクトリーを、Releseフォルダへ丸ごとコピー！
//  最後にReleseディレクトリ内のサイトスナップショットを取って、ショットのはいったフォルダごと、ZIP化してbuildフォルダに書き出します。
//
//  ワードプレスにこのまま、ZIP書き込み登録可能。
//  また、サイト保存としても役立ちます。
//
//************************************************************************************



//# HTML組み合わせツール
gulp.task("ejs", function() {

   // 最新のサイト定義JSONファイルを同期読み込みしてオブジェクトを生成
    var json = JSON.parse(fs.readFileSync("deploy/site.json", 'utf8'));
    gulp.src(
        ["deploy/ejs/**/*.ejs",'!' + "deploy/ejs/**/_*.ejs"] //注1
    )
    //# 監視用ツール エラーがあったら、タスクバーで窓表示します。
      .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
//        .pipe(ejs())
        .pipe(ejs(json))
      //# HTMLのインデントを綺麗に揃える
      .pipe(prettify({indent_size: 2}))
        .pipe(gulp.dest("deploy/release"))//注2
        .pipe(browserSync.reload({stream:true}));
});


//# HTMLのインデントを綺麗に揃える
gulp.task('prettify', function() {
  gulp.src('src/*.html')
      //# 監視用ツール エラーがあったら、タスクバーで窓表示します。
    .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
    .pipe(prettify({indent_size: 2}))
    .pipe(gulp.dest('dist'));
});



//# HTML文法チェック
gulp.task('hlint', function() {
    gulp.src('deploy/release**/*.html')
    //# 監視用ツール エラーがあったら、タスクバーで窓表示します。
    .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
      //ファイルが更新された時に反応するように設定
//      .pipe(cache('htmlhint_log'))
      //htmlhintrc.json設定を元に、文法をチェック
        .pipe(htmlhint('htmlhintrc.json'))
        .pipe(htmlhint.reporter());
});


//# HTMLバリデーターチェック(なんか見にくいのだ・・・だからやめたのだ・・・)
gulp.task('htmlv', function () {
  gulp.src('deploy/release/**/*.html')
    //# 監視用ツール エラーがあったら、タスクバーで窓表示します。
    .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
    .pipe(htmlv())
    .pipe(gulp.dest('deploy/release/w3c'));
});



//# HTML5文法チェック（実はいらない（ぇ が、念のため保持
gulp.task('h5lint', function() {
    return gulp.src('deploy/release/**/*.html')
    //# 監視用ツール エラーがあったら、タスクバーで窓表示します。
    .pipe(plumber({errorHandler: notify.onError('<%= error.message %>')}))
        .pipe(html5Lint());
});


//# サイトマップXML作成
gulp.task('sitemap', function () {
    gulp.src('deploy/release/**/*.html')
        .pipe(sitemap({
            siteUrl: '<%= pkg.url %>'
        }))
        .pipe(gulp.dest('deploy/release'));
});



//# 各デバイス向けfaviconを作成します。
//var    favicons = require('../');
var favicons =require("gulp-favicons");

gulp.task('favicon', function () {
    gulp.src('deploy/release/images/def_favicon.png')
    .pipe(favicons({
        // ...
        html: "index.html"         // HTML files to modify. `string` or `array`
    }))
    .pipe(gulp.dest('./deploy/release/images/favicon/'));
});


//# htaccess設定を作ります。
gulp.task("hta",function(){
return gulp.src(
  ['.htaccess'],
  { base: './' }
  )
  .pipe(gulp.dest('deploy/release/'));
});




//******** サイトのスナップショットを撮る**********************************************************
//
//  index.htmlのサイトのスナップショットを、Wordpress用、FB用に取得しています。
//  rename(リネーム)をして、名前を変更する処理を別途それぞれに入れています。
//  ※ネーム名＆保存場所、EJSタブリンクに対応済み
//
//************************************************************************************


//# 制作中のサイトのスナップショットを撮る：：：ワードプレス用とFacebook用の画像設定です。
//gulp.task('shot', ['wp'],['fb']);
gulp.task('shot', ['wp']);


//# wordpress用スクリーンショット設定
gulp.task('wp', ['wordshot'],function() {

  return gulp.src('deploy/release/index.png')
        .pipe(rename({
            basename: " screenshot",
        }))
        .pipe(gulp.dest('deploy/release/'));
  });

gulp.task('wordshot', function() {
//  return gulp.src('./Theme/**/**.html')
//    return gulp.src('release/index.html')
    return gulp.src('deploy/release/index.html')
//        .pipe(webshot({ dest:'build/',root:'Theme'}));
        .pipe(webshot({
            dest:'deploy/release/',
//            dest:'Theme/',//ワードプレステーマの場合は、themeフォルダTOPに、スクリーンショットを置く。
            root:'deploy/release/',
            windowSize:({  //ワードプレステーマ用サイズ
            width: "1366",
            height: "768"}),
             screenSize: ({
              width:"1366",
              height:"768"
//             width: 880,
//             height: '660'
            }),
             shotSize: ({
             width: 880,
             height: '660'
            })
        }));
});


//# Facebook用スクリーンショット設定
gulp.task('fb', ['fbshot'],function() {

  return gulp.src('deploy/release/index.png')
        .pipe(rename({
            basename: " fb",
        }))
        .pipe(gulp.dest('deploy/release/'));
  });

gulp.task('fbshot', function() {
//  return gulp.src('./Theme/**/**.html')
    return gulp.src('deploy/release/index.html')
//        .pipe(webshot({ dest:'build/',root:'Theme'}));
        .pipe(webshot({
            dest:'release/',
//            dest:'Theme/',//ワードプレステーマの場合は、themeフォルダTOPに、スクリーンショットを置く。
            root:'release',

            screenSize:({  //FB用ORG指定サイズ
            width: "1200",
            height: "630"}
            )
        }));
});



//******** サイト完成Build処理まとめ**********************************************************
//
//  サイト作成が終わったものを、サイトのスナップショットを撮り、自動的にZIP化。
//  その後、開発環境（deploy)で不要になった（Releaseにコピーしたデーター）を、全削除しています。
//
//************************************************************************************




//# サイトヘッダーバナーをファイルに付与する。（CSS,JSなどに）
gulp.task('header', function () {

//# ヘッダーバナー作成 npm int時の「プロジェクト設定」をそのまま読み込みます。
var pkg = require('./package.json');
var BANNER = [
  '@charset "utf-8";',
  '/**',
  ' * <%= pkg.name %> - <%= pkg.description %>',
  ' * @link <%= pkg.url %>',
  ' * @version v<%= pkg.version %>',
  ' * @Author <%= pkg.author %>',
  ' * @Author URI <%= pkg.author %>',
  ' */',
  ''
].join('\n');

//# 上に書いたバナー設定を読み込みます。
//gulp.src('./_release/css/*.js')
//  .pipe(header(banner, { pkg : pkg } ))
//  .pipe(gulp.dest('./dist/')) //←ここの設定に気をつける。

// NOTE: a line separator will not be added automatically バージョン
//gulp.src('./foo/*.js')
//  .pipe(header('Hello'))
//  .pipe(gulp.dest('./dist/')) //←ここの設定に気をつける。


// ejs style templatingバージョン
//gulp.src('./foo/*.js')
//  .pipe(header('Hello <%= name %>\n', { name : 'World'} ))
//  .pipe(gulp.dest('./dist/')) //←ここの設定に気をつける。


// ES6-style template stringバージョン
//gulp.src('./foo/*.js')
//  .pipe(header('Hello ${name}\n', { name : 'World'} ))
//  .pipe(gulp.dest('./dist/')) //←ここの設定に気をつける。
//


//# テキストに用意したバナー設定を読み込みます。
var fs = require('fs');
gulp.src('./deploy/release/css/*.css')
  .pipe(header(fs.readFileSync('header_banner.txt', 'utf8'), { pkg : pkg } ))
  .pipe(gulp.dest('./deploy/release/css'));
});




//# サイトヘッダーバナーをファイルに付与する。（CSS,JSなどに）
gulp.task('footer', function () {

//# ヘッダーバナー作成 npm int時の「プロジェクト設定」をそのまま読み込みます。
var pkg = require('./package.json');
var BANNER = [
  '@charset "utf-8";',
  '/**',
  ' * <%= pkg.name %> - <%= pkg.description %>',
  ' * @link <%= pkg.url %>',
  ' * @version v<%= pkg.version %>',
  ' * @Author <%= pkg.author %>',
  ' * @Author URI <%= pkg.author %>',
  ' */',
  ''
].join('\n');

//# 上に書いたバナー設定を読み込みます。
//gulp.src('./_release/css/*.js')
//  .pipe(footer(banner, { pkg : pkg } ))
//  .pipe(gulp.dest('./dist/')) //←ここの設定に気をつける。

// NOTE: a line separator will not be added automatically バージョン
//gulp.src('./foo/*.js')
//  .pipe(footer('Hello'))
//  .pipe(gulp.dest('./dist/')) //←ここの設定に気をつける。


// ejs style templatingバージョン
//gulp.src('./foo/*.js')
//  .pipe(footer('Hello <%= name %>\n', { name : 'World'} ))
//  .pipe(gulp.dest('./dist/')) //←ここの設定に気をつける。


// ES6-style template stringバージョン
//gulp.src('./foo/*.js')
//  .pipe(footer('Hello ${name}\n', { name : 'World'} ))
//  .pipe(gulp.dest('./dist/')) //←ここの設定に気をつける。


//# テキストに用意したバナー設定を読み込みます。
var fs = require('fs');
gulp.src('./deploy/release/css/*.css')
  .pipe(footer(fs.readFileSync('footer_banner.txt', 'utf8'), { pkg : pkg } ))
  .pipe(gulp.dest('deploy/release/css'));
});




//# 制作完了したサイトデーター(ディレクトリ）を_releaseフォルダへコピーする。
gulp.task( 'copy', function() {
    return gulp.src(
        [ 'deploy/release/*.html', 'deploy/release/css/**', 'deploy/release/js/**/*.js', 'deploy/release/fonts/**', 'deploy/release/images/**' ],
        { base: 'deploy/release' }
    )
    .pipe( gulp.dest( 'release' ) );
} );





//# 制作完了ディレクトリーをZIP化する。
gulp.task('zip', function () {
    return gulp.src('release/*')
        .pipe(zip('build.zip'))
        .pipe(gulp.dest('build'));
});


//# いらないファイル・ディレクトリを削除する
gulp.task('clean',
    del.bind(null,
        ['deploy/release*'],
        {dot: true}));








